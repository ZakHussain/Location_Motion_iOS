//
//  CreateUserViewController.swift
//  Location Motion
//
//  Created by Zak Hussain on 9/16/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//


import UIKit

class UserViewController: UITableViewController, CancelButtonDelegate, AddUserViewControllerDelegate{
    var Users: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("MyCell")!
        cell.textLabel?.text = Users[indexPath.row]
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Users.count
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "AddUserSegue" {
            let navigationController = segue.destinationViewController as! UINavigationController
            let controller = navigationController.topViewController as! AddUserViewController
            controller.cancelButtonDelegate = self
            controller.delegate = self
        }
    }
    func cancelButtonPressedFrom(controller: UIViewController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    func addUserViewController(controller: AddUserViewController, didFinishAddingUser mission: String) {
        dismissViewControllerAnimated(true, completion: nil)
        Users.append(mission)
        tableView.reloadData()
    }

}