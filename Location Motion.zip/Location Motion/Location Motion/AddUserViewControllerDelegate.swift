//
//  AddUserViewControllerDelegate.swift
//  Location Motion
//
//  Created by Zak Hussain on 9/16/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//

import Foundation

protocol AddUserViewControllerDelegate: class {
    func addUserViewController(controller: AddUserViewController, didFinishAddingUser mission: String)
}