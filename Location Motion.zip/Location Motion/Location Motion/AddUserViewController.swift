//
//  AddUserViewController.swift
//  Location Motion
//
//  Created by Zak Hussain on 9/16/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//

import Foundation
import UIKit

class AddUserViewController: UITableViewController{
   
    @IBOutlet weak var newUserTextField: UITextField!
    weak var cancelButtonDelegate: CancelButtonDelegate?
    weak var delegate: AddUserViewControllerDelegate?
    
    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate?.cancelButtonPressedFrom(self)
    }
    @IBAction func doneBarButtonPressed (sender: UIBarButtonItem) {
         print("done button pressed")
        delegate?.addUserViewController(self, didFinishAddingUser: newUserTextField.text!)
    }
}