//
//  ViewController.swift
//  Location Motion
//
//  Created by Zak Hussain on 9/16/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//

import UIKit

class LocationMotionViewController: UIViewController {

    @IBAction func beginPushButton(sender: UIButton) {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

